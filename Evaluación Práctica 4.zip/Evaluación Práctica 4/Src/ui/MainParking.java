import java.util.Scanner;

public class MainParking {
    public static void main(String[] args) {
        // Crear instancia de la clase Parking
        Parking parking = new Parking("123456789", "MyParking");

        Scanner scanner = new Scanner(System.in);

        // Alquilar un espacio de estacionamiento
        System.out.println("Ingrese los datos para alquilar un espacio:");
        System.out.print("Placa del vehículo: ");
        String plate = scanner.nextLine();
        System.out.print("Identificación del propietario: ");
        String identification = scanner.nextLine();
        System.out.print("Número de celular del propietario: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Nombre del propietario: ");
        String ownerName = scanner.nextLine();
        System.out.print("Identificación autorizada: ");
        String autorizedId = scanner.nextLine();
        System.out.print("Valor de la mensualidad: ");
        double valueMonth = scanner.nextDouble();

        String result = parking.spaceRent(plate, identification, phoneNumber, ownerName, autorizedId, valueMonth);
        System.out.println(result);

        // Mostrar información del cliente
        System.out.println("Ingrese la identificación del cliente para mostrar su información:");
        String clientId = scanner.next();
        String clientInfo = parking.showInfoClient(clientId);
        System.out.println(clientInfo);

        // Obtener espacios disponibles por piso
        String spacesAvailable = parking.spaceAvailableFloor();
        System.out.println(spacesAvailable);

        // Obtener número del piso con más espacios ocupados
        String maxOccupiedFloor = parking.maxFloorOccupied();
        System.out.println(maxOccupiedFloor);

        scanner.close();
    }
}

package model;

import java.util.ArrayList;
import java.util.List;

class Parking {
    private double PAYMONTH;
    private String nit;
    private String name;

    public Parking(String nit, String name) {
        this.nit = nit;
        this.name = name;
    }

    public String spaceRent(String plate, String identification, String phoneNumber, String ownerName, String autorizedId, double valueMonth) {
        // Lógica para alquilar un espacio de estacionamiento
        // ...
        return "Space rented successfully";
    }

    public String showInfoClient(String identification) {
        // Lógica para mostrar la información del cliente
        // ...
        return "Client info: ...";
    }

    public String spaceAvailableFloor() {
        // Lógica para obtener los espacios disponibles por piso
        // ...
        return "Spaces available per floor: ...";
    }

    public String maxFloorOccupied() {
        // Lógica para obtener el número del piso con más espacios ocupados
        // ...
        return "Max occupied floor: ...";
    }
}
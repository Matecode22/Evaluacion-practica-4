
class Space {
    private int id;
    private boolean available;
    private double valueMonth;

    public Space(int id) {
        this.id = id;
        this.available = true;
        this.valueMonth = 0.0;
    }

    // Getters and setters
}
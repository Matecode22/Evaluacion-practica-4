import java.util.ArrayList;
import java.util.List;

class Parking {
    private double PAYMONTH;
    private String nit;
    private String name;
    private List<Space> spaces;

    public Parking(String nit, String name) {
        this.nit = nit;
        this.name = name;
        this.spaces = new ArrayList<>();
    }

    public String spaceRent(String plate, String identification, String phoneNumber, String ownerName, String authorizedId, double valueMonth) {
        Space availableSpace = findAvailableSpace();
        if (availableSpace != null) {
            availableSpace.setPlate(plate);
            availableSpace.setIdentification(identification);
            availableSpace.setPhoneNumber(phoneNumber);
            availableSpace.setOwnerName(ownerName);
            availableSpace.setAuthorizedId(authorizedId);
            availableSpace.setValueMonth(valueMonth);
            availableSpace.setAvailable(false);
            return "Space rented successfully";
        } else {
            return "No available spaces";
        }
    }

    public String showInfoClient(String identification) {
        StringBuilder clientInfo = new StringBuilder("Client info:\n");
        for (Space space : spaces) {
            if (!space.isAvailable() && space.getIdentification().equals(identification)) {
                clientInfo.append(space.toString()).append("\n");
            }
        }
        return clientInfo.toString();
    }

    public String spaceAvailableFloor() {
        StringBuilder spacesAvailable = new StringBuilder("Spaces available per floor:\n");
        int[] availableSpacesByFloor = getAvailableSpacesByFloor();
        for (int i = 0; i < availableSpacesByFloor.length; i++) {
            spacesAvailable.append("Floor ").append(i + 1).append(": ").append(availableSpacesByFloor[i]).append(" spaces\n");
        }
        return spacesAvailable.toString();
    }

    public String maxFloorOccupied() {
        int[] occupiedSpacesByFloor = getOccupiedSpacesByFloor();
        int maxOccupiedFloor = 0;
        int maxOccupiedSpaces = occupiedSpacesByFloor[0];
        for (int i = 1; i < occupiedSpacesByFloor.length; i++) {
            if (occupiedSpacesByFloor[i] > maxOccupiedSpaces) {
                maxOccupiedFloor = i;
                maxOccupiedSpaces = occupiedSpacesByFloor[i];
            }
        }
        return "Max occupied floor: " + (maxOccupiedFloor + 1);
    }

    private Space findAvailableSpace() {
        for (Space space : spaces) {
            if (space.isAvailable()) {
                return space;
            }
        }
        return null;
    }

    private int[] getAvailableSpacesByFloor() {
        int[] availableSpacesByFloor = new int[8];
        for (Space space : spaces) {
            if (space.isAvailable()) {
                availableSpacesByFloor[space.getFloor() - 1]++;
            }
        }
        return availableSpacesByFloor;
    }

    private int[] getOccupiedSpacesByFloor() {
        int[] occupiedSpacesByFloor = new int[8];
        for (Space space : spaces) {
            if (!space.isAvailable()) {
                occupiedSpacesByFloor[space.getFloor() - 1]++;
            }
        }
        return occupiedSpacesByFloor;
    }
}

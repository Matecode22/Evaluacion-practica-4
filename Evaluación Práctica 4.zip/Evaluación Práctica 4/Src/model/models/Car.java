package models;

class Car {
    private String plate;
    private String identification;
    private String ownerName;
    private String ownerMobile;
    private String authorizedId;

    public Car(String plate, String identification, String ownerName, String ownerMobile, String authorizedId) {
        this.plate = plate;
        this.identification = identification;
        this.ownerName = ownerName;
        this.ownerMobile = ownerMobile;
        this.authorizedId = authorizedId;
    }

    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerMobile() {
        return ownerMobile;
    }

    public void setOwnerMobile(String ownerMobile) {
        this.ownerMobile = ownerMobile;
    }

    public String getAuthorizedId() {
        return authorizedId;
    }

    public void setAuthorizedId(String authorizedId) {
        this.authorizedId = authorizedId;
    }

    @Override
    public String toString() {
        return "Plate: " + plate +
                "\nIdentification: " + identification +
                "\nOwner Name: " + ownerName +
                "\nOwner Mobile: " + ownerMobile +
                "\nAuthorized ID: " + authorizedId;
    }
}
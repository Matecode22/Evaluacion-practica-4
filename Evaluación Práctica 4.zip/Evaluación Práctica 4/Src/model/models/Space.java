package models;

class Space {
    private int id;
    private int floor;
    private int number;
    private boolean isWideSpace;
    private boolean available;
    private String plate;
    private String identification;
    private String phoneNumber;
    private String ownerName;
    private String authorizedId;
    private double valueMonth;

    public Space(int floor, int number, boolean isWideSpace) {
        this.id = generateId(floor, number);
        this.floor = floor;
        this.number = number;
        this.isWideSpace = isWideSpace;
        this.available = true;
    }

    public int getId() {
        return id;
    }

    public int getFloor() {
        return floor;
    }

    public int getNumber() {
        return number;
    }

    public boolean isWideSpace() {
        return isWideSpace;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getAuthorizedId() {
        return authorizedId;
    }

    public void setAuthorizedId(String authorizedId) {
        this.authorizedId = authorizedId;
    }

    public double getValueMonth() {
        return valueMonth;
    }

    public void setValueMonth(double valueMonth) {
        this.valueMonth = valueMonth;
    }

    private int generateId(int floor, int number) {
        return (floor * 100) + number;
    }

    @Override
    public String toString() {
        return "Space ID: " + id +
                "\nFloor: " + floor +
                "\nNumber: " + number +
                "\nWide Space: " + isWideSpace +
                "\nAvailable: " + available +
                "\nPlate: " + plate +
                "\nIdentification: " + identification +
                "\nPhone Number: " + phoneNumber +
                "\nOwner Name: " + ownerName +
                "\nAuthorized ID: " + authorizedId +
                "\nValue Month: " + valueMonth;
    }
}
